package org.software;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletCalculadora
 */
@WebServlet("/ServletCalculadora")
public class ServletCalculadora extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletCalculadora() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		
		System.out.println("01");
		// capturar los parametros del formulario
		String operacion = request.getParameter("operacion");
		String textN1 = request.getParameter("n1");
		String textN2 = request.getParameter("n2");
		
		System.out.println("02");
		// convertir String a double
		double n1 = Double.parseDouble(textN1);
		double n2 = Double.parseDouble(textN2);
		
		System.out.println("03");
		// crear un objeto calculadora
		Calculadora casio = new Calculadora();
		
		System.out.println("04");
		// definir la variable resultado
		double resultado = 0.0;
		
		// ejecutar la operacion - obtener el resultado
		switch(operacion){
		case "sumar":
			resultado = casio.sumar(n1, n2);
			break;
		case "restar":
			resultado = casio.restar(n1, n2);
			break;
		case "multiplicar":
			resultado = casio.multiplicar(n1, n2);
			break;
		case "dividir":
			resultado = casio.dividir(n1, n2);
			break;
		}
		System.out.println("05");
		
		PrintWriter out = response.getWriter();
		
		out.println(operacion + "(" + n1 + "," + n2 + ") = " + resultado);
		
	}

}

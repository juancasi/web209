package org.software;

public class Calculadora {
	
	public double sumar(double n1, double n2) {
		double suma = n1 + n2;
		return suma;
	}
	
	public double restar(double n1, double n2) {
		double resta = n1 - n2;
		return resta;
	}
	
	public double multiplicar(double n1, double n2) {
		double multiplicacion = n1 * n2;
		return multiplicacion;
	}
	
	public double dividir(double n1, double n2) {
		double division = n1 / n2;
		return division;
	}
	
}
